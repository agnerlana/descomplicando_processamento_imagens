## Pacote de Processamento de imagens

Descricao:
Pacote dio_processador_imagens indicado para:
    Processamento:
    - Correspondencia de histogramas
    - Similaridade estrutural
    - Redimensionamento de imagens

    Utils (auxiliares):
    - Leitura de imagens
    - Salvamento de imagens
    - Plot de imagens, resultados e histogramas

## Instalacao

Utilize o gerenciador de pacotes [pip](https://pip.pypa.io/en/stable/) para instalar dio_processador_imagens


<!-- bash
pip install dio_processador_imagens
-->


## Autores
Karina;
Agner


## License
[MIT](https://choosealicense.com/license/mit/)